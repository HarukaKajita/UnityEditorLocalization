#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Kajitaharuka.EditorLocalization
{
    /// <summary>
    /// Unity Editor拡張向けの軽量ローカライズAPI。
    /// scopeごとのmanifestをAssetDatabaseから読み込み、選択ロケールとfallbackに従って文言を返す。
    /// </summary>
    public static class EditorL10n
    {
        private static EditorL10nCatalog _catalog;
        private static readonly HashSet<string> ReportedDiagnostics = new();
        // Editor UI からの利用はメインスレッド前提のため、キャッシュ操作にロックは設けない。
        private static readonly Dictionary<(string Locale, string DefaultLocale), string[]> FallbackChainCache = new();

        // システム（OS）由来のロケールタグの供給元。既定は CultureInfo から読む。
        // テストから差し替えてシステム言語フォールバックを環境非依存に検証できるようにする。
        internal static Func<string> SystemLocaleProvider = ReadSystemLocaleTag;

        // GetSystemLocale の正規化結果を直近の供給元出力でメモ化する。GetActiveLocale は Tr のたびに
        // 呼ばれるため、正規化（Split/LINQ/Join）の再計算を避ける。生タグをキーにするので、テストでの
        // 供給元差し替えや OS 言語変更時は自動で再計算され、陳腐化しない。
        private static string _systemLocaleRaw;
        private static string _systemLocaleNormalized = "";

        public static event Action LocaleChanged;

        internal static EditorL10nCatalog Catalog => _catalog ??= EditorL10nCatalog.Load();

        /// <summary>
        /// 全 scope 共通で使う表示ロケールを返す。未設定の場合は空文字を返す。
        /// </summary>
        public static string GetGlobalLocale()
        {
            return NormalizeLocaleTag(EditorL10nPreferences.GlobalLocale);
        }

        /// <summary>
        /// 全 scope 共通で使う表示ロケールを設定する。空文字を指定すると未設定へ戻す。
        /// </summary>
        public static void SetGlobalLocale(string locale)
        {
            var normalizedLocale = NormalizeLocaleTag(locale);
            EditorL10nPreferences.GlobalLocale = normalizedLocale;
            LocaleChanged?.Invoke();
        }

        /// <summary>
        /// OS の UI 言語から推定した表示ロケールタグ（正規化済み）を返す。判定できない場合は空文字。
        /// 検出は Unity の `Application.systemLanguage`（OS の優先言語を確実に取得。macOS でも信頼可）を
        /// 主とし、地域は `CultureInfo` で補い、未対応の言語は `CultureInfo`→空へ degrade する。
        /// enum 利用はこの「検出（既定の推定）」に限り、カタログ/解決はあくまで文字列タグのみで扱う
        /// （言語を増やしても解決ロジックの C# は不変）方針は維持する。
        /// </summary>
        public static string GetSystemLocale()
        {
            var raw = SystemLocaleProvider?.Invoke() ?? "";
            if (raw != _systemLocaleRaw)
            {
                _systemLocaleRaw = raw;
                _systemLocaleNormalized = NormalizeLocaleTag(raw);
            }
            return _systemLocaleNormalized;
        }

        /// <summary>
        /// グローバル設定が未設定のとき、システム（OS）言語へフォールバックするかどうかを返す。既定は有効。
        /// </summary>
        public static bool GetSystemLocaleFallbackEnabled()
        {
            return EditorL10nPreferences.SystemLocaleFallbackEnabled;
        }

        /// <summary>
        /// システム言語フォールバックの有効/無効を設定する。変更時は LocaleChanged を発火し UI を追従させる。
        /// </summary>
        public static void SetSystemLocaleFallbackEnabled(bool enabled)
        {
            EditorL10nPreferences.SystemLocaleFallbackEnabled = enabled;
            LocaleChanged?.Invoke();
        }

        public static string GetActiveLocale(string scope)
        {
            return GetActiveLocale(scope, out _);
        }

        /// <summary>
        /// 表示ロケールを解決し、由来（source）も返す。優先順は
        /// scope 個別設定 → グローバル設定 → システム言語（有効時）→ scope の defaultLocale。
        /// 解決順の単一情報源とし、UI 側はこの source を表示にそのまま使う。
        /// </summary>
        internal static string GetActiveLocale(string scope, out EditorL10nLocaleSource source)
        {
            var normalizedScope = scope ?? "";

            var scopeLocale = NormalizeLocaleTag(EditorL10nPreferences.GetScopeLocale(normalizedScope));
            if (!string.IsNullOrEmpty(scopeLocale))
            {
                source = EditorL10nLocaleSource.ScopeOverride;
                return scopeLocale;
            }

            var globalLocale = NormalizeLocaleTag(EditorL10nPreferences.GlobalLocale);
            if (!string.IsNullOrEmpty(globalLocale))
            {
                source = EditorL10nLocaleSource.Global;
                return globalLocale;
            }

            if (EditorL10nPreferences.SystemLocaleFallbackEnabled)
            {
                var systemLocale = GetSystemLocale();
                if (!string.IsNullOrEmpty(systemLocale))
                {
                    source = EditorL10nLocaleSource.System;
                    return systemLocale;
                }
            }

            source = EditorL10nLocaleSource.Default;
            return Catalog.TryGetScope(normalizedScope, out var scopeCatalog)
                ? scopeCatalog.DefaultLocale
                : "";
        }

        public static void SetActiveLocale(string scope, string locale)
        {
            var normalizedLocale = NormalizeLocaleTag(locale);
            EditorL10nPreferences.SetScopeLocale(scope, normalizedLocale);
            LocaleChanged?.Invoke();
        }

        public static IReadOnlyList<EditorL10nLocaleInfo> GetLocales(string scope)
        {
            return Catalog.TryGetScope(scope ?? "", out var scopeCatalog)
                ? scopeCatalog.Locales
                : Array.Empty<EditorL10nLocaleInfo>();
        }

        /// <summary>
        /// scopeのdefaultLocaleやmanifestパスなど、表示補助用のメタ情報を取得する。
        /// </summary>
        public static bool TryGetScopeInfo(string scope, out EditorL10nScopeInfo info)
        {
            if (Catalog.TryGetScope(scope ?? "", out var scopeCatalog))
            {
                info = new EditorL10nScopeInfo(
                    scopeCatalog.Scope,
                    scopeCatalog.DefaultLocale,
                    scopeCatalog.ManifestPath);
                return true;
            }

            info = null;
            return false;
        }

        /// <summary>
        /// scope の指定 locale のテーブルアセットパスを取得する（検証結果から該当 JSON へジャンプする用途）。
        /// </summary>
        public static bool TryGetLocaleTablePath(string scope, string locale, out string tablePath)
        {
            tablePath = "";
            return Catalog.TryGetScope(scope ?? "", out var scopeCatalog)
                && scopeCatalog.TryGetTablePath(NormalizeLocaleTag(locale), out tablePath);
        }

        /// <summary>
        /// scope の指定 locale テーブルに含まれる key 数を返す（scope/locale が未登録なら false）。
        /// Preferences のカタログ一覧で翻訳の進み具合を一目で示す表示用。
        /// </summary>
        internal static bool TryGetEntryCount(string scope, string locale, out int count)
        {
            count = 0;
            if (!Catalog.TryGetScope(scope ?? "", out var scopeCatalog))
                return false;
            if (!scopeCatalog.TablesByLocale.TryGetValue(NormalizeLocaleTag(locale), out var table))
                return false;
            count = table.Count;
            return true;
        }

        public static IReadOnlyList<string> GetScopes()
        {
            return Catalog.Scopes.Select(scope => scope.Scope).OrderBy(scope => scope).ToArray();
        }

        public static string Tr(string scope, string key, params object[] args)
        {
            if (TryTranslate(scope, key, out var text))
            {
                if (args == null || args.Length == 0)
                    return text;
                try
                {
                    return string.Format(text, args);
                }
                catch (FormatException e)
                {
                    Debug.LogError($"EditorLocalization: formatに失敗しました: {scope}/{key}: {e.Message}");
                    return text;
                }
            }

            return key ?? "";
        }

        public static bool TryTranslate(string scope, string key, out string text)
        {
            text = "";
            if (string.IsNullOrEmpty(scope) || string.IsNullOrEmpty(key))
                return false;

            if (!Catalog.TryGetScope(scope, out var scopeCatalog))
            {
                LogMissingScopeOnce(scope, key);
                return false;
            }

            foreach (var locale in GetFallbackChain(GetActiveLocale(scope), scopeCatalog.DefaultLocale))
            {
                if (scopeCatalog.TryGetText(locale, key, out text))
                    return true;
            }

            LogMissingKeyOnce(scope, key);
            return false;
        }

        public static void Reload()
        {
            _catalog = EditorL10nCatalog.Load();
            FallbackChainCache.Clear();
            ReportedDiagnostics.Clear();
            LocaleChanged?.Invoke();
        }

        private static void LogMissingScopeOnce(string scope, string key)
        {
            LogDiagnosticOnce(
                "scope",
                scope,
                key,
                $"EditorLocalization: 未知の scope です: {scope} (key={key})");
        }

        private static void LogMissingKeyOnce(string scope, string key)
        {
            LogDiagnosticOnce(
                "key",
                scope,
                key,
                $"EditorLocalization: 未解決の key です: {scope}/{key}");
        }

        private static void LogDiagnosticOnce(string category, string scope, string key, string message)
        {
            if (!EditorL10nPreferences.DiagnosticsEnabled)
                return;

            var diagnosticKey = $"{category}\u001f{scope}\u001f{key}";
            if (ReportedDiagnostics.Add(diagnosticKey))
                Debug.LogWarning(message);
        }

        internal static string[] GetFallbackChain(string locale, string defaultLocale)
        {
            var key = (locale ?? "", defaultLocale ?? "");
            if (FallbackChainCache.TryGetValue(key, out var cachedChain))
                return cachedChain;

            var chain = BuildFallbackChain(locale, defaultLocale).ToArray();
            FallbackChainCache.Add(key, chain);
            return chain;
        }

        internal static IEnumerable<string> BuildFallbackChain(string locale, string defaultLocale)
        {
            var yielded = new HashSet<string>();
            foreach (var candidate in EnumerateLocaleAndParents(NormalizeLocaleTag(locale)))
            {
                if (!string.IsNullOrEmpty(candidate) && yielded.Add(candidate))
                    yield return candidate;
            }

            foreach (var candidate in EnumerateLocaleAndParents(NormalizeLocaleTag(defaultLocale)))
            {
                if (!string.IsNullOrEmpty(candidate) && yielded.Add(candidate))
                    yield return candidate;
            }
        }

        internal static IEnumerable<string> EnumerateLocaleAndParents(string locale)
        {
            var current = NormalizeLocaleTag(locale);
            while (!string.IsNullOrEmpty(current))
            {
                yield return current;
                var index = current.LastIndexOf('-');
                current = index <= 0 ? "" : current.Substring(0, index);
            }
        }

        public static string NormalizeLocaleTag(string locale)
        {
            if (string.IsNullOrWhiteSpace(locale))
                return "";

            var parts = locale.Trim().Replace('_', '-').Split('-');
            for (var i = 0; i < parts.Length; i++)
            {
                var part = parts[i];
                if (string.IsNullOrEmpty(part))
                    continue;

                if (i == 0)
                    parts[i] = part.ToLowerInvariant();
                else if (part.Length == 4 && part.All(char.IsLetter))
                    parts[i] = char.ToUpperInvariant(part[0]) + part.Substring(1).ToLowerInvariant();
                else if (part.Length == 2 && part.All(char.IsLetter))
                    parts[i] = part.ToUpperInvariant();
                else
                    parts[i] = part.ToLowerInvariant();
            }

            return string.Join("-", parts.Where(part => !string.IsNullOrEmpty(part)));
        }

        // OS の優先言語（Application.systemLanguage）を主に、地域を CultureInfo で補ってタグを組む。
        // enum で判定できない言語は CultureInfo へ degrade し、それも空なら空文字（フォールバックをスキップ）。
        private static string ReadSystemLocaleTag()
        {
            var languageTag = SystemLanguageToTag(Application.systemLanguage);
            if (!string.IsNullOrEmpty(languageTag))
                return RefineWithRegion(languageTag, ReadCultureTag());

            return ReadCultureTag();
        }

        // CurrentUICulture を優先し、Invariant 等で空なら InstalledUICulture（OS 設定言語）を試す。
        private static string ReadCultureTag()
        {
            var current = CultureInfo.CurrentUICulture;
            if (current != null && !string.IsNullOrEmpty(current.Name))
                return current.Name;

            var installed = CultureInfo.InstalledUICulture;
            if (installed != null && !string.IsNullOrEmpty(installed.Name))
                return installed.Name;

            return "";
        }

        // 言語のみのタグ（例 ja）に、CultureInfo の地域（例 ja-JP）を、言語が一致するときだけ補う。
        // script を含むタグ（例 zh-Hans）は地域で上書きせず保持する。enum 検出の信頼性を CultureInfo で損なわせない。
        internal static string RefineWithRegion(string languageTag, string cultureTag)
        {
            if (string.IsNullOrEmpty(cultureTag) || languageTag.IndexOf('-') >= 0)
                return languageTag;

            var cultureLanguage = FirstSubtag(cultureTag);
            return string.Equals(cultureLanguage, languageTag, StringComparison.OrdinalIgnoreCase)
                ? cultureTag
                : languageTag;
        }

        private static string FirstSubtag(string tag)
        {
            var index = tag.IndexOf('-');
            return index < 0 ? tag : tag.Substring(0, index);
        }

        // Unity の SystemLanguage を BCP-47 言語タグへ対応付ける（検出専用。未対応は空文字で degrade）。
        // ここはロケールの「検出（既定の推定）」のための表であり、カタログ/解決のロケール定義ではない。
        // 表に無い言語もカタログ追加だけで利用可能で、必要なら 1 行追加で OS 自動検出に対応できる。
        internal static string SystemLanguageToTag(SystemLanguage language)
        {
            return language switch
            {
                SystemLanguage.Afrikaans => "af",
                SystemLanguage.Arabic => "ar",
                SystemLanguage.Basque => "eu",
                SystemLanguage.Belarusian => "be",
                SystemLanguage.Bulgarian => "bg",
                SystemLanguage.Catalan => "ca",
                SystemLanguage.Chinese => "zh-Hans",
                SystemLanguage.ChineseSimplified => "zh-Hans",
                SystemLanguage.ChineseTraditional => "zh-Hant",
                SystemLanguage.Czech => "cs",
                SystemLanguage.Danish => "da",
                SystemLanguage.Dutch => "nl",
                SystemLanguage.English => "en",
                SystemLanguage.Estonian => "et",
                SystemLanguage.Faroese => "fo",
                SystemLanguage.Finnish => "fi",
                SystemLanguage.French => "fr",
                SystemLanguage.German => "de",
                SystemLanguage.Greek => "el",
                SystemLanguage.Hebrew => "he",
                SystemLanguage.Hungarian => "hu",
                SystemLanguage.Icelandic => "is",
                SystemLanguage.Indonesian => "id",
                SystemLanguage.Italian => "it",
                SystemLanguage.Japanese => "ja",
                SystemLanguage.Korean => "ko",
                SystemLanguage.Latvian => "lv",
                SystemLanguage.Lithuanian => "lt",
                SystemLanguage.Norwegian => "nb",
                SystemLanguage.Polish => "pl",
                SystemLanguage.Portuguese => "pt",
                SystemLanguage.Romanian => "ro",
                SystemLanguage.Russian => "ru",
                SystemLanguage.SerboCroatian => "sr",
                SystemLanguage.Slovak => "sk",
                SystemLanguage.Slovenian => "sl",
                SystemLanguage.Spanish => "es",
                SystemLanguage.Swedish => "sv",
                SystemLanguage.Thai => "th",
                SystemLanguage.Turkish => "tr",
                SystemLanguage.Ukrainian => "uk",
                SystemLanguage.Vietnamese => "vi",
                _ => "",
            };
        }
    }

    /// <summary>表示ロケールの由来。Preferences が「現在この言語になっている理由」を示すために使う。</summary>
    internal enum EditorL10nLocaleSource
    {
        ScopeOverride,
        Global,
        System,
        Default,
    }
}
#endif
